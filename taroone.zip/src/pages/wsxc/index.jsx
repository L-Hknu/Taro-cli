import Taro, { PureComponent } from '@tarojs/taro';
import { View, Text, Button } from '@tarojs/components';

class Wsxc extends PureComponent {

  config = {
    navigationBarTitleText: ''
  }

  state = {}


  render() {
    return (
      <View>
        1121
      </View>
    );
  }
}
export default Wsxc;