export const ORDER_LIST = '/service/order/order_list.jsp';
export const MOCK = 'http://rap2api.taobao.org/app/mock';