import counterStore from './counter';
import homeStore from './home';
const store = {
  counterStore,
  homeStore
};

export default store;