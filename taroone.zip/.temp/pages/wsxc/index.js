import Nerv from "nervjs";
import Taro from "@tarojs/taro-h5";
import { View } from '@tarojs/components';

class Wsxc extends Taro.PureComponent {

  config = {
    navigationBarTitleText: ''
  };

  state = {};

  render() {
    return <View>
        1121
      </View>;
  }
}
export default Wsxc;