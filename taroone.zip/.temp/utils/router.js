import Taro, { switchTab as _switchTab } from "@tarojs/taro-h5";
import { parseUrlData } from './utils';

export function navigateTo(url, obj) {
  url = '/pages/' + url;
  if (obj) url += parseUrlData(obj);
  Taro.navigateTo({ url });
}

export function redirectTo(url) {
  url = '/pages/' + url;
  Taro.redirectTo(url);
}

export function navigateBack(delta = 1) {
  Taro.navigateBack({ delta });
}

export function switchTab(url) {
  url = '/pages/' + url;
  _switchTab(url);
}